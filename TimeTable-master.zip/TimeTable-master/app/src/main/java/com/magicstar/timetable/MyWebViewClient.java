package com.magicstar.timetable;

import android.webkit.WebViewClient;

class MyWebViewClient extends WebViewClient {
}
